#!/bin/bash
nsys profile --trace=cuda,nvtx,mpi,openacc $*
