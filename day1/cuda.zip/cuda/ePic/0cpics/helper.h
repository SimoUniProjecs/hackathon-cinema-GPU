#pragma once

// File: helper.h
#ifndef HELPER_H
#define HELPER_H

#include <stdio.h>
#include <cuda_runtime.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>

// Maximum number of dimensions (can be up to 3)
#define MAX_DIM 3

// Function to measure time
double cpuSecond() {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((double)ts.tv_sec + (double)ts.tv_nsec * 1.e-9);
}

// Struct for Particle
struct Particle {
    double pos[MAX_DIM], vel[MAX_DIM], E[MAX_DIM];  // Use MAX_DIM as the fixed size for arrays
    double q, m;
};

// Struct for ParticleList
struct ParticleList {
    struct Particle* parts;
    int n;
};

// Function to initialize a particle
void initParticle(struct Particle* p, int DIM) {
    // Random number generator initialization
    for (int i = 0; i < DIM; ++i) {  // Use the runtime DIM to control how many dimensions are used
        p->pos[i] = rand() / (double)RAND_MAX;  // Random position
        p->vel[i] = 1.0 - 2.0 * (rand() / (double)RAND_MAX);  // Random velocity in range [-1, 1]
    }
    p->q = -1.0;  // Charge
    p->m = 1.0;   // Mass
}

// Initialize a list of particles
void initParticleList(struct ParticleList* pl, int n, int DIM) {
    pl->n = n;
    pl->parts = (struct Particle*)malloc(n * sizeof(struct Particle));
    for (int i = 0; i < n; ++i) {
        initParticle(&pl->parts[i], DIM);
    }
}

// Free memory allocated for particle list
void freeParticleList(struct ParticleList* pl) {
    free(pl->parts);
}

// Set the electric field for each particle
void setE(struct ParticleList* pl, int DIM) {
    for (int i = 0; i < pl->n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            pl->parts[i].E[j] = sin(M_PI * pl->parts[i].pos[j]);
        }
    }
}

// Accelerate particles by updating their velocity
void accel(struct ParticleList* pl, double dt, int DIM) {
    for (int i = 0; i < pl->n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            pl->parts[i].vel[j] += dt * pl->parts[i].q / pl->parts[i].m * pl->parts[i].E[j];
        }
    }
}

// Move particles by updating their position
void move(struct ParticleList* pl, double dt, int DIM) {
    for (int i = 0; i < pl->n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            pl->parts[i].pos[j] += dt * pl->parts[i].vel[j];
            // Apply periodic boundary conditions
            if (pl->parts[i].pos[j] > 1.0) {
                pl->parts[i].pos[j] -= 1.0;
            }
            if (pl->parts[i].pos[j] < 0.0) {
                pl->parts[i].pos[j] += 1.0;
            }
        }
    }
}

// Function to print data
void printData(struct ParticleList* pl, double t, FILE* outFile, int DIM) {
    fprintf(outFile, "Time: %f\n", t);
    for (int i = 0; i < pl->n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            fprintf(outFile, "%f ", pl->parts[i].pos[j]);
        }
        fprintf(outFile, "%f\n", pl->parts[i].E[0]); // Print one electric field component
    }
    fprintf(outFile, "\n");
}

// Function to print sample particle data
void printSampleData(struct ParticleList* pl, int n, int DIM) {
    printf("Sample particle data:\n");
    int samples = n < 5 ? n : 5;  // Limit to 5 samples or fewer if less than 5 particles
    for (int i = 0; i < samples; ++i) {
        printf("Particle %d:\n", i);
        
        // Print Position
        printf("  Position: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->parts[i].pos[j]);
        }
        printf("\n");

        // Print Velocity
        printf("  Velocity: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->parts[i].vel[j]);
        }
        printf("\n");

        // Print Electric Field
        printf("  Electric Field: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->parts[i].E[j]);
        }
        printf("\n");
    }
}

// Function to get the current time in seconds
double getTime() {
    return (double)clock() / CLOCKS_PER_SEC;
}

#endif // HELPER_H

