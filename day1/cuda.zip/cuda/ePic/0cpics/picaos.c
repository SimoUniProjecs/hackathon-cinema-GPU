#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "helper.h"
#include "nvtx3/nvToolsExt.h"


#define N 10000000  // Define the number of particles
#define MAX_DIM 3  // Define the maximum number of dimensions (for Particle structure)

int main(int argc, char* argv[]) {

    const int ndumps = 1000;  // Must be an integer
    printf("Number of particles: %d\n", N);

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <dimension (1, 2, or 3)>\n", argv[0]);
        return 1;
    }

    // Set dimension of the problem (1, 2, or 3)
    int DIM = atoi(argv[1]);
    if (DIM < 1 || DIM > MAX_DIM) {
        fprintf(stderr, "Dimension must be 1, 2, or 3.\n");
        return 1;
    }

    // Time step
    double dt = 0.1;

    // Initialize particle list
    struct ParticleList p;
    initParticleList(&p, N, DIM);  // N is now defined as the number of particles

    // Open file to save results
    FILE* outFile = fopen("results_aos.txt", "w");
    if (outFile == NULL) {
        fprintf(stderr, "Failed to open results_aos.txt for writing.\n");
        return 1;
    }

    // Start timing
    double start = getTime();

    // Main simulation loop
    int step = 0;
    for (double t = 0; t < 1; t += dt, ++step) {
	nvtxRangePush("Time Step"); 
        nvtxRangePush("setE");	
        setE(&p, DIM);  // Update electric field for all particles
	nvtxRangePop(); //SetE
	nvtxRangePush("accel");
        accel(&p, dt, DIM);  // Update velocities of all particles
        nvtxRangePop(); // Accel
	nvtxRangePush("move");
	move(&p, dt, DIM);  // Update positions of all particles
	nvtxRangePop(); 
	nvtxRangePop(); // Time Step

        // Save data every ndumps steps
        if (step % ndumps == 0) {
            printData(&p, t, outFile, DIM);  // Save particle data
        }
    }

    // Stop timing
    double stop = getTime();
    printf("Simulation time: %f seconds\n", stop - start);

    // Print sample data for a few particles
    printSampleData(&p, N, DIM);

    // Free allocated memory and close file
    freeParticleList(&p);
    fclose(outFile);

    printf("Data has been written to results_aos.txt\n");

    return 0;
}

