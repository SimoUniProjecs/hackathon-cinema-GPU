#pragma once

// File: helper.h
#ifndef HELPER_H
#define HELPER_H

#include <stdio.h>
#include <cuda_runtime.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>

// Maximum number of dimensions (can be up to 3)
#define MAX_DIM 3

// Function to measure time
double cpuSecond() {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((double)ts.tv_sec + (double)ts.tv_nsec * 1.e-9);
}

// Struct for ParticleList (now using Structure of Arrays)
struct ParticleList {
    double *pos[MAX_DIM];  // Array of pointers for position components
    double *vel[MAX_DIM];  // Array of pointers for velocity components
    double *E[MAX_DIM];    // Array of pointers for electric field components
    double *q;             // Array for charges
    double *m;             // Array for masses
    int n;                 // Number of particles
};

// Function to initialize the particle list
void initParticleList(struct ParticleList* pl, int n, int DIM) {
    pl->n = n;
    
    // Allocate memory for each array
    for (int i = 0; i < DIM; ++i) {
        pl->pos[i] = (double*)malloc(n * sizeof(double));
        pl->vel[i] = (double*)malloc(n * sizeof(double));
        pl->E[i] = (double*)malloc(n * sizeof(double));
    }
    pl->q = (double*)malloc(n * sizeof(double));
    pl->m = (double*)malloc(n * sizeof(double));

    // Initialize particles
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            pl->pos[j][i] = rand() / (double)RAND_MAX;  // Random position
            pl->vel[j][i] = 1.0 - 2.0 * (rand() / (double)RAND_MAX);  // Random velocity in range [-1, 1]
        }
        pl->q[i] = -1.0;  // Charge
        pl->m[i] = 1.0;   // Mass
    }
}

// Free memory allocated for particle list
void freeParticleList(struct ParticleList* pl, int DIM) {
    for (int i = 0; i < DIM; ++i) {
        free(pl->pos[i]);
        free(pl->vel[i]);
        free(pl->E[i]);
    }
    free(pl->q);
    free(pl->m);
}

// Set the electric field for each particle
void setE(struct ParticleList* pl, int DIM) {
    for (int j = 0; j < DIM; ++j) {
        for (int i = 0; i < pl->n; ++i) {
            pl->E[j][i] = sin(M_PI * pl->pos[j][i]);
        }
    }
}

// Accelerate particles by updating their velocity
void accel(struct ParticleList* pl, double dt, int DIM) {
    for (int j = 0; j < DIM; ++j) {
        for (int i = 0; i < pl->n; ++i) {
            pl->vel[j][i] += dt * pl->q[i] / pl->m[i] * pl->E[j][i];
        }
    }
}

// Move particles by updating their position
void move(struct ParticleList* pl, double dt, int DIM) {
    for (int j = 0; j < DIM; ++j) {
        for (int i = 0; i < pl->n; ++i) {
            pl->pos[j][i] += dt * pl->vel[j][i];
            // Apply periodic boundary conditions
            if (pl->pos[j][i] > 1.0) {
                pl->pos[j][i] -= 1.0;
            }
            if (pl->pos[j][i] < 0.0) {
                pl->pos[j][i] += 1.0;
            }
        }
    }
}

// Function to print data
void printData(struct ParticleList* pl, double t, FILE* outFile, int DIM) {
    fprintf(outFile, "Time: %f\n", t);
    for (int i = 0; i < pl->n; ++i) {
        for (int j = 0; j < DIM; ++j) {
            fprintf(outFile, "%f ", pl->pos[j][i]);
        }
        fprintf(outFile, "%f\n", pl->E[0][i]); // Print one electric field component
    }
    fprintf(outFile, "\n");
}

// Function to print sample particle data
void printSampleData(struct ParticleList* pl, int n, int DIM) {
    printf("Sample particle data:\n");
    int samples = n < 5 ? n : 5;  // Limit to 5 samples or fewer if less than 5 particles
    for (int i = 0; i < samples; ++i) {
        printf("Particle %d:\n", i);
        
        // Print Position
        printf("  Position: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->pos[j][i]);
        }
        printf("\n");

        // Print Velocity
        printf("  Velocity: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->vel[j][i]);
        }
        printf("\n");

        // Print Electric Field
        printf("  Electric Field: ");
        for (int j = 0; j < DIM; ++j) {
            printf("%f ", pl->E[j][i]);
        }
        printf("\n");
    }
}

// Function to get the current time in seconds
double getTime() {
    return (double)clock() / CLOCKS_PER_SEC;
}

#endif // HELPER_H
